package chhaya.chaudhari.masterdataservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MasterDataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
