package chhaya.chaudhari.connectionbuilderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectionBuilderServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
