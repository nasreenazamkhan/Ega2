export default {
  zoomLevel: 2.5,
  apiKey: "AIzaSyDEkxJNQFjBdFMzOueMCl1Qsk1RtPvAOvg",
  streetViewControl: false,
  gestureHandling: "auto",
  mapTypeControl: false,
  fullscreenControl: false,
  center: {
    lat: 36.15752575135864,
    lng: -0.9788087008131827,
  },
};